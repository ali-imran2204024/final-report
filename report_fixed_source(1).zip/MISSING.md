# Khoj — Report Missing Items & Manual Fill Checklist

This document tracks all external, personal, or runtime assets that could not be determined strictly from the codebase and proposal, and need to be provided or verified manually before final submission.

---

## 1. Team & Academic Metadata (`report/config.tex`)
- [ ] **Contact Numbers**: The proposal includes names and student IDs, but contact numbers are placeholders (`01700000001` .. `01700000004`).
- [ ] **CGPA and Total Credits Passed**: Update the exact current CGPA and credits passed in `report/config.tex` for:
  - Abdullah Al Azim (2204012)
  - Ali Imran (2204024)
  - Sojeeb Mojumder (2204029)
  - Majharul Islam (2204032)
- [ ] **Team Member Photos**: Place individual formal portrait photos inside `report/images/photos/`:
  - `images/photos/2204012.jpg`
  - `images/photos/2204024.jpg`
  - `images/photos/2204029.jpg`
  - `images/photos/2204032.jpg`
- [ ] **Official CUET Logo**: Replace `report/images/cuet_logo.png` with the official high-resolution CUET crest if higher resolution is required.

---

## 2. Source Code Repository & Live URLs
- [ ] **Official Group Repository Link**: Replace `https://github.com/[TODO: Group-Repository]/khoj` with the real team repository URL in `report/appendices/appendixA_source_code.tex`.
- [ ] **Live Web Deployment URL**: If the project has been deployed live on Vercel and Render, update the public URL in Chapter 8 and Appendix A.

---

## 3. Application Screenshots (Appendix C)
Because local runtime dependencies (`node_modules`) and a live local PostgreSQL instance were not initialized in the static environment, UI screenshots are tracked as clean placeholders. When running the live application, capture high-resolution browser screenshots and place them in `report/images/` to automatically replace the placeholders:
- [ ] `screenshot_home.png` — Landing page with Hero, AI Search input, and Closing Soon card grid.
- [ ] `screenshot_browse.png` — Browse catalog with multi-parameter filter controls (Category, City, Mode) and event cards.
- [ ] `screenshot_details.png` — Event details view showing banner, metadata grid, outlink registration button, and discussion comments.
- [ ] `screenshot_organizer.png` — Organizer dashboard listing published events, status badges, and statistics.
- [ ] `screenshot_submit_ai.png` — Event submission form showing raw text paste area, AI extraction action, and auto-populated fields.
- [ ] `screenshot_admin.png` — Admin dashboard moderation queue with Approve and Reject actions.
- [ ] `screenshot_profile.png` — User profile view showing registered events and saved bookmarks.

---

## 4. AI Empirical Benchmark Metrics
- [ ] **AI Benchmark Execution Dataset**: As documented in Section 7.7, the automated guardrails and schema validation were verified, while the empirical precision/recall benchmark scores on the 50-circular corpus are tracked as `[TODO: Run Full AI Benchmark Evaluation Suite]` in `report/chapters/ch07_testing.tex` to avoid fabricating unverified experimental numbers.

---

## 5. Local Compilation & Overleaf Upload
- [ ] **Local Build (Optional)**: Neither `pdflatex` nor `latexmk` is currently in the host Windows PATH. To compile locally, install [MiKTeX](https://miktex.org/download) or run `choco install miktex` in an elevated shell.
- [x] **Overleaf Ready (Recommended)**: The self-contained zip archive `report_overleaf.zip` has been generated in the workspace root. Upload it directly to [Overleaf](https://www.overleaf.com) via **New Project -> Upload Project**, set the compiler to **pdfLaTeX**, and compile with one click.
